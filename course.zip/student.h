/**
 * @file student.h
 * @date 2022-04-11
 * 
 */

/**
 * @brief A Student typedef struct containing a string first name, a string last name, a string id, a double list of grades, and an int number of grades.
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
