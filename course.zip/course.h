/**
 * @file course.h
 * @date 2022-04-11
 * 
 */
#include "student.h"
#include <stdbool.h>
 
/**
 * @brief A Course typedef struct containing a string name, a string code, the students in the course, and an int of the total amount of students.
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


